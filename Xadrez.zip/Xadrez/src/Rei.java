import java.util.ArrayList;

public class Rei extends Peca{

    private boolean primeiroMov;

    @Override
    public ArrayList<Posicao> possiveisMovimentos(Tabuleiro tabuleiro) {
        return null;
    }
}
