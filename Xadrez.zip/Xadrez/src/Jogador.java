import java.util.ArrayList;

public class Jogador {
    private String nome="";
    private String cor="";
    private double pontos;
    private String senha="";
    private ArrayList<Peca> pecas = new ArrayList<>();

    public boolean moverPeca( Peca peca, Posicao posicao){


        return true;
    }
    public boolean proporEmpate(Jogador jogador){
        return true;
    }
    public void desistir(){

    }


}
