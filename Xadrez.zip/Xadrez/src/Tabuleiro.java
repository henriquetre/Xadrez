import java.util.ArrayList;

public class Tabuleiro {
    private ArrayList<Posicao> listaDePosicaoes= new ArrayList<>();

    public void removerPeca(Posicao posicao){

    }

    public ArrayList<Posicao> getListaDePosicaoes() {
        return listaDePosicaoes;
    }
}
